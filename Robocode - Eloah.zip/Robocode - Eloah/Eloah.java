package Eloah;
import robocode.*;
import java.awt.Color;

// API help : http://robocode.sourceforge.net/docs/robocode/robocode/Robot.html

/**
 * Eloah - a robot by (your name here)
 */
public class Eloah extends Robot
{

	public void run() {
	
		 setBodyColor(Color.yellow); 
		 setRadarColor(Color.black); 
		 setGunColor(Color.red); 
				 

		// Robot main loop
		while(true) {
			ahead(300);
			turnRight(90);
			turnGunRight(360);
			back(100);
			turnLeft(90);
			turnGunLeft(360);
		}
	}

	public void onScannedRobot(ScannedRobotEvent e) {
		fire(3);
		back(50);
	}


	public void onHitByBullet(HitByBulletEvent e) {
		back(100);
		turnLeft(90);
	}
	
	public void onHitWall(HitWallEvent e) {
		back(100);
		turnRight(90);
	}	
}
